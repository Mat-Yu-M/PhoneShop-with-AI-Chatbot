<?php
include 'db_connection.php';

// Fetch only Apple products from the database
$sql = "SELECT * FROM products WHERE brand = 'Samsung'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Samsung - Jaden's Online Phone Shop</title>
    <link rel="stylesheet" href="products.css">
</head>
<body>

<?php include 'components/Header.php'; ?>

<main>
    <h1>Samsung</h1>
    <div class="product-grid">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="product-card">
                    <img src="<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>">
                    <h3><?php echo $row['name']; ?></h3>
                    <p class="price">₱<?php echo number_format($row['price'], 2); ?></p>
                    <p class="stock">Stock: <?php echo $row['stock']; ?></p>
                    <a href="product_details.php?id=<?php echo $row['id']; ?>" class="btn">View Details</a>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="no-products">No Samsung products available at the moment.</p>
        <?php endif; ?>
    </div>
</main>

<?php include 'components/Footer.php'; ?>

</body>
</html>