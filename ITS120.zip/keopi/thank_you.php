<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You - Jaden's Online Phone Shop</title>
    <link rel="stylesheet" href="products.css">
</head>
<body>
    <?php include 'components/Header.php'; ?>

    <main>
        <div style="text-align: center; padding: 50px;">
            <h1>Thank You for Your Order!</h1>
            <p>Your order has been successfully placed.</p>
            <a href="Products.php" class="btn">Continue Shopping</a>
        </div>
    </main>

    <?php include 'components/Footer.php'; ?>
</body>
</html> 