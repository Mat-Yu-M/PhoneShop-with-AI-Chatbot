<?php
include 'db_connection.php';

// Fetch all products from the database
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Jaden’s Online Phone Shop</title>
    <link rel="stylesheet" href="products.css">
</head>
<body>

<?php include 'components/Header.php'; ?>

<main>
    <h1>Our Products</h1>
    <div class="product-grid">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="product-card">
                <img src="<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>">
                <h3><?php echo $row['name']; ?></h3>
                <p class="price">₱<?php echo number_format($row['price'], 2); ?></p>
                <p>Stock: <?php echo $row['stock']; ?></p>
                <a href="product_details.php?id=<?php echo $row['id']; ?>" class="btn">View Details</a>
            </div>
        <?php endwhile; ?>
    </div>
</main>

<?php include 'components/Footer.php'; ?>

</body>
</html>