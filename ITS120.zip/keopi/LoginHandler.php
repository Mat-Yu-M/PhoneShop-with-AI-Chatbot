<?php
session_start();
include 'db_connection.php';

// Enable error reporting for debugging (REMOVE in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// If user is already logged in, redirect to the appropriate page
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'employee') {
        header("Location: dashboard.php");
    } else {
        header("Location: home.php");
    }
    exit();
}

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Ensure database connection is working
    if (!$conn) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    // Fetch user from the database
    $sql = "SELECT id, full_name, email, password, role FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Query preparation failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if ($user) {
        // Verify password (check if it's hashed)
        if (password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['email'] = $user['email']; // ✅ Store email in session
            $_SESSION['role'] = $user['role'];

            // Redirect based on role
            if ($user['role'] === 'employee') {
                header("Location: dashboard.php");
            } else {
                header("Location: home.php");
            }
            exit();
        } else {
            // Incorrect password
            header("Location: Login.php?error=Invalid password");
            exit();
        }
    } else {
        // No user found
        header("Location: Login.php?error=No user found with that email");
        exit();
    }
}

// Close database connection
$conn->close();
?>
