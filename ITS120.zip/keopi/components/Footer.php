<footer style="background-color: #FF5722; color: white; padding: 20px; display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap;">
    <div style="flex: 1; padding: 10px; min-width: 250px;">
        <h3 style="margin-bottom: 10px;">About Us</h3>
        <p style="line-height: 1.6;">
            At Jaden’s Online Phone Shop , we strive to bring the latest and most innovative smartphones and accessories to your fingertips. 
            Our mission is to connect people to cutting-edge technology with unparalleled convenience and affordability.
        </p>
    </div>
    <div style="flex: 1; padding: 10px; min-width: 250px; text-align:right;">
        <h3 style="margin-bottom: 10px;">Contact Us</h3>
        <p style="line-height: 1.6;">
            Have questions? We'd love to hear from you!<br>
            📧 Email: <a href="mailto:support@keopi.com" style="color: #FFE0B2; text-decoration: none;">support@keopi.com</a><br>
            ☎️ Phone: +1-800-123-4567<br>
            🕒 Business Hours: Mon-Fri, 9:00 AM - 6:00 PM
        </p>
    </div>
</footer>
