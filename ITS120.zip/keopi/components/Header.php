<?php require 'style.php'; ?>

<header>
    <h1>Jaden's Online Phone Shop</h1>
    <div class="account">
        <?php if (isset($_SESSION['role'])): ?>
            <?php if ($_SESSION['role'] === 'customer'): ?>
                <a href="Account.php" class="nav-link">Account</a>
                <a href="Cart.php" class="nav-link cart-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart">
                        <circle cx="9" cy="21" r="1"></circle>
                        <circle cx="20" cy="21" r="1"></circle>
                        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                    </svg>
                </a>
            <?php elseif ($_SESSION['role'] === 'employee'): ?>
                <a href="Account.php" class="nav-link">Account</a>
            <?php endif; ?>
        <?php else: ?>
            <a href="Login.php" class="nav-link">Login</a>
            <a href="Register.php" class="nav-link">Register</a>
        <?php endif; ?>
    </div>
    <style>
        header {
            background-color: #FF5722;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
        }

        header h1 {
            margin: 0;
            font-size: 1.5rem;
        }

        .navigation {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .account {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .nav-link {
            color: white;
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .cart-icon {
            display: inline-flex;
            align-items: center;
            padding: 0.5rem;
        }

        @media (max-width: 768px) {
            header {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }

            .navigation, .account {
                flex-wrap: wrap;
                justify-content: center;
            }
        }
    </style>
</header>

<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<nav>
    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'employee'): ?>
        <a href="Dashboard.php" class="<?php echo ($current_page == 'Dashboard') ? 'active' : ''; ?>">DASHBOARD</a>
        <a href="Transactions.php" class="<?php echo ($current_page == 'Transactions') ? 'active' : ''; ?>">TRANSACTIONS</a>
    <?php else: ?>
        <a href="Home.php" class="<?php echo ($current_page == 'Home') ? 'active' : ''; ?>">HOME</a>
        <a href="Products.php" class="<?php echo ($current_page == 'Products') ? 'active' : ''; ?>">PRODUCTS</a>
        <a href="Apple.php" class="<?php echo ($current_page == 'Apple') ? 'active' : ''; ?>">APPLE</a>
        <a href="Oppo.php" class="<?php echo ($current_page == 'Oppo') ? 'active' : ''; ?>">OPPO</a>
        <a href="Redmi.php" class="<?php echo ($current_page == 'Redmi') ? 'active' : ''; ?>">REDMI</a>
        <a href="Oneplus.php" class="<?php echo ($current_page == 'Oneplus') ? 'active' : ''; ?>">ONEPLUS</a>
        <a href="Samsung.php" class="<?php echo ($current_page == 'Samsung') ? 'active' : ''; ?>">SAMSUNG</a>
    <?php endif; ?>
</nav>
