<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Origin: *");

$conn = new mysqli("localhost", "root", "", "keopi_db");

if ($conn->connect_error) {
    die(json_encode(["error" => "Database connection failed"]));
}

// Get the requested resource from the URL
$request_uri = $_SERVER['REQUEST_URI'];
$path = parse_url($request_uri, PHP_URL_PATH);
$path_parts = explode('/', trim($path, '/'));
$resource = end($path_parts);

switch ($resource) {
    case 'orders':
        $sql = "SELECT * FROM orders";
        break;
    case 'users':
        $sql = "SELECT * FROM users";
        break;
    case 'products':
        $sql = "SELECT * FROM products";
        break;
    default:
        http_response_code(404);
        echo json_encode(["error" => "Resource not found"]);
        exit();
}

$result = $conn->query($sql);

if (!$result) {
    http_response_code(500);
    echo json_encode(["error" => "Database query failed: " . $conn->error]);
    exit();
}

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
$conn->close();
?>