<?php
session_start();
include 'db_connection.php';

// Ensure the request is from an employee
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    header("Location: Login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];

    if ($action === "add") {
        // Add new customer
        $full_name = trim($_POST['full_name']);
        $email = trim($_POST['email']);
        $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);

        $sql = "INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, 'customer')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $full_name, $email, $password);

        if ($stmt->execute()) {
            header("Location: dashboard.php");
        }
        $stmt->close();
    } elseif ($action === "delete") {
        $id = $_POST['id'];
        $sql = "DELETE FROM users WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            header("Location: dashboard.php");
        }
        $stmt->close();
    }
}

$conn->close();
?>
