<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Fetch product details
    $sql = "SELECT * FROM products WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();

    // Store in session (basic cart system)
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    $_SESSION['cart'][$product_id] = [
        'name' => $product['name'],
        'price' => $product['price'],
        'quantity' => $quantity,
        'image' => $product['image']
    ];

    echo "<script>alert('Added to cart!'); window.location.href='cart.php';</script>";
}

// Display cart
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart - Jaden's Online Phone Shop</title>
    <link rel="stylesheet" href="cart.css">
</head>
<body>

<?php include 'components/Header.php'; ?>

<main>
    <h1>Shopping Cart</h1>
    <div class="cart-container">
        <?php if (!empty($cart)): ?>
            <?php foreach ($cart as $id => $item): ?>
                <div class="cart-item">
                    <img src="<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>">
                    <div class="cart-item-details">
                        <h3><?php echo $item['name']; ?></h3>
                        <p>Price: ₱<?php echo number_format($item['price'], 2); ?></p>
                        <p>Quantity: <?php echo $item['quantity']; ?></p>
                    </div>
                    <form action="remove_from_cart.php" method="post">
                        <input type="hidden" name="product_id" value="<?php echo $id; ?>">
                        <button type="submit">Remove</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>

        <div class="checkout">
            <form method="POST" action="process_checkout.php">
                <button type="submit" class="btn">Proceed to Checkout</button>
            </form>
        </div>
    </div>
</main>

<?php include 'components/Footer.php'; ?>

</body>
</html>

