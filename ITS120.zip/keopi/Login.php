<?php
session_start();

// Check for login errors
$error_message = isset($_GET['error']) ? htmlspecialchars($_GET['error']) : "";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jaden's Online Phone Shop - Login</title>
    <link rel="stylesheet" href="Login.css">
</head>

<body>

    <?php include 'components/Header.php'; ?>

    <main>
        <h1>Login</h1>

        <?php if (!empty($error_message)): ?>
            <p class="error"><?php echo $error_message; ?></p>
        <?php endif; ?>

        <div class="form-container">
            <form action="LoginHandler.php" method="post">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="login">Login</button>
            </form>
        </div>

        <p>Don't have an account? <a href="Register.php">Sign up</a></p>
    </main>

    <?php include 'components/Footer.php'; ?>

</body>

</html>
